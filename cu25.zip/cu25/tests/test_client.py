"""End-to-end flow against a fake 25Live that answers like the real one did in the HAR."""
import json
from datetime import date, datetime, timedelta
from pathlib import Path

import httpx
import pytest

from cu25 import client as C

FX = Path(__file__).parent / "fixtures"
load = lambda n: json.loads((FX / n).read_text())


@pytest.fixture
def fake(tmp_path):
    state = tmp_path / "s.json"
    state.write_text(json.dumps({"cookies": [{"name": "JSESSIONID", "value": "x",
                                              "domain": "25live.collegenet.com", "path": "/"}]}))
    calls = []

    def handler(req: httpx.Request):
        path = req.url.path.split("/run/")[1]
        body = json.loads(req.content) if req.content else None
        calls.append((req.method, path, dict(req.url.params), body))
        if path == "sequence/id.json":
            sid = 561543 if req.url.params["itemName"] == "events" else 636747
            return httpx.Response(200, json={"sequence": {"sequence_id": sid}})
        if path == "event.json":
            return httpx.Response(201, json={"events": {"event": {"event_id": 561543}}})
        if path == "micro/sequence/generate.json":
            return httpx.Response(200, json={"content": {"data": {"items": [
                {"idSet": [{"rsrvId": 9482714}]}]}}})
        if path.startswith("micro/event/"):
            return httpx.Response(200, json=load("event_detail.json"))
        if path == "space_avail.json":
            return httpx.Response(200, json=load("space_avail.json"))
        if path == "rose/event.json":
            return httpx.Response(201, json=load("submit_response.json"))
        if path == "spaces.json" and req.method == "POST":
            return httpx.Response(200, json=load("space_detail.json"))
        if path == "login.json":
            return httpx.Response(200, json=load("login.json"))
        return httpx.Response(404)

    c = C.Client(state_file=state)
    c.http = httpx.Client(transport=httpx.MockTransport(handler), headers=c.http.headers)
    return c, calls


def soon(days, hour):
    d = date.today() + timedelta(days=days)
    return datetime(d.year, d.month, d.day, hour)


def test_book_usual_runs_the_same_sequence_as_the_browser(fake):
    c, calls = fake
    out = c.request_room(561543, soon(3, 17), soon(3, 18))
    assert out["reference"] == "2026-ACWQJD" and out["state"] == "Tentative"
    seq = [(m, p) for m, p, _, _ in calls]
    assert seq == [
        ("GET", "micro/event/561543/detail.json"),
        ("POST", "space_avail.json"),
        ("GET", "sequence/id.json"),
        ("GET", "sequence/id.json"),
        ("PUT", "event.json"),
        ("POST", "micro/sequence/generate.json"),
        ("PUT", "rose/event.json"),
    ]
    submit = calls[-1][3]["events"]["event"]
    assert submit["state"] == 1 and submit["event_id"] == "561543"
    assert submit["profile"][0]["reservation"][0]["reservation_id"] == 9482714


def test_dry_run_never_writes(fake):
    c, calls = fake
    out = c.request_room(561543, soon(3, 17), soon(3, 18), dry_run=True)
    assert out["dry_run"]
    assert all(m in ("GET", "POST") and p != "rose/event.json" for m, p, _, _ in calls)
    assert not any(p in ("event.json", "rose/event.json") for _, p, _, _ in calls)


def test_tomorrow_is_rejected_day_after_is_fine():
    with pytest.raises(C.CU25Error):
        C.check_lead_time(soon(1, 17))
    C.check_lead_time(soon(2, 17))


def test_taken_room_is_refused(fake):
    c, calls = fake
    # 164 (STM206) has a conflict in the fixture
    with pytest.raises(C.CU25Error, match="taken"):
        c.request_room(561543, soon(3, 14), soon(3, 15), space_id=164, layout_id=23)


def test_whoami(fake):
    c, _ = fake
    assert c.whoami()["netid"] == "netid"


def test_expired_session_is_clear(tmp_path):
    st = tmp_path / "s.json"; st.write_text('{"cookies": []}')
    c = C.Client(state_file=st)
    c.http = httpx.Client(transport=httpx.MockTransport(
        lambda r: httpx.Response(302, headers={"location": "https://shibidp.cit.cornell.edu"})))
    with pytest.raises(C.SessionExpired, match="cu25 login"):
        c.whoami()
