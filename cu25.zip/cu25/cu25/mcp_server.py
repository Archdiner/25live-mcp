"""MCP server so an agent can say 'book our usual spot Thursday 5pm' and have it happen."""
from __future__ import annotations

from datetime import datetime

try:  # MCP SDK 2.x
    from mcp.server.mcpserver import MCPServer as _Server
except ImportError:  # MCP SDK 1.x
    from mcp.server.fastmcp import FastMCP as _Server

from .client import Client, CU25Error, SessionExpired, load_config, save_config

mcp = _Server("cu25")


def _dt(day: str, hhmm: str) -> datetime:
    return datetime.fromisoformat(f"{day}T{hhmm}")


def _run(fn):
    try:
        return fn()
    except (SessionExpired, CU25Error) as e:
        return {"error": str(e)}


@mcp.tool()
def find_rooms(date: str, start: str, end: str, people: int | None = None,
               name: str | None = None) -> list | dict:
    """Find Cornell rooms you can request. date YYYY-MM-DD, start/end HH:MM (24h, Ithaca time).
    name filters by building/room (e.g. 'stimson'). Free rooms are listed first."""
    return _run(lambda: Client().find_rooms(_dt(date, start), _dt(date, end), name=name, people=people))


@mcp.tool()
def book_room(date: str, start: str, end: str, room_id: int | None = None,
              title: str | None = None, people: int | None = None,
              template_event_id: int | None = None, dry_run: bool = False) -> dict:
    """Submit a 25Live room request by cloning the user's usual event (org, type, form answers)
    onto a new date and time. Omit room_id for the usual room. Requests must be at least
    2 days out. Returns the reference code; the request is Tentative until a scheduler approves."""
    template = template_event_id or load_config().get("usual_event_id")
    if not template:
        return {"error": "No usual event set. Ask the user for an event id and call set_usual."}
    return _run(lambda: Client().request_room(
        template, _dt(date, start), _dt(date, end),
        space_id=room_id, name=title, people=people, dry_run=dry_run))


@mcp.tool()
def set_usual(event_id: int) -> dict:
    """Remember an existing 25Live event as the template for future bookings
    (the number in the event's URL, e.g. .../event/561543/details)."""
    def go():
        tpl = Client().event_template(event_id)
        save_config({**load_config(), "usual_event_id": event_id})
        return {"usual": tpl["event_name"], "space_id": tpl["space_id"],
                "people": tpl["expected_count"]}
    return _run(go)


@mcp.tool()
def request_status(event_id: int) -> dict:
    """Check whether a request is Tentative, Confirmed, Denied, or Cancelled."""
    return _run(lambda: Client().event_status(event_id))


def main():
    mcp.run()


if __name__ == "__main__":
    main()
