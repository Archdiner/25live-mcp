"""HTTP client for Cornell's 25Live, riding the user's own logged-in session."""
from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from pathlib import Path

import httpx

from . import payload as P

HOME = Path.home() / ".cu25"
STATE_FILE = HOME / "session.json"   # Playwright storage state (cookies)
CONFIG_FILE = HOME / "config.json"   # {"usual_event_id": 561543}
BASE = "https://25live.collegenet.com/25live/data/cornell/run"
MIN_DAYS_AHEAD = 2  # Cornell won't take same-day or next-day requests


class SessionExpired(RuntimeError):
    pass


class CU25Error(RuntimeError):
    pass


def load_config() -> dict:
    return json.loads(CONFIG_FILE.read_text()) if CONFIG_FILE.exists() else {}


def save_config(cfg: dict) -> None:
    HOME.mkdir(exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def check_lead_time(start: datetime, today: date | None = None) -> None:
    today = today or date.today()
    if start.date() < today + timedelta(days=MIN_DAYS_AHEAD):
        raise CU25Error(
            f"{start:%a %b %d} is too soon. Requests need to be at least "
            f"{MIN_DAYS_AHEAD} days out (earliest: {today + timedelta(days=MIN_DAYS_AHEAD):%a %b %d})."
        )


class Client:
    def __init__(self, state_file: Path = STATE_FILE):
        if not state_file.exists():
            raise SessionExpired("Not logged in. Run: cu25 login")
        state = json.loads(state_file.read_text())
        jar = httpx.Cookies()
        for c in state.get("cookies", []):
            if "collegenet.com" in c.get("domain", ""):
                jar.set(c["name"], c["value"], domain=c["domain"], path=c.get("path", "/"))
        self.http = httpx.Client(
            cookies=jar,
            timeout=30,
            follow_redirects=False,
            headers={
                "accept": "application/json, text/plain, */*",
                "content-type": "application/json",
                "origin": "https://25live.collegenet.com",
                "referer": "https://25live.collegenet.com/pro/cornell",
                "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36",
            },
        )

    # ---- plumbing -------------------------------------------------------
    def _call(self, method: str, path: str, query: str = "", body: dict | None = None) -> dict:
        sep = "&" if query else ""
        url = f"{BASE}/{path}?{query}{sep}caller=pro"
        r = self.http.request(method, url, content=json.dumps(body) if body is not None else None)
        if r.status_code in (301, 302, 303, 401, 403) or "text/html" in r.headers.get("content-type", ""):
            raise SessionExpired("25Live session expired. Run: cu25 login")
        if r.status_code >= 400:
            raise CU25Error(f"{method} {path} failed ({r.status_code}): {r.text[:300]}")
        return r.json() if r.content else {}

    def _seq(self, item: str) -> int:
        return self._call("GET", "sequence/id.json", f"itemName={item}")["sequence"]["sequence_id"]

    # ---- reads ----------------------------------------------------------
    def whoami(self) -> dict:
        login = self._call("GET", "login.json")["login_response"]["login"]
        if login.get("success") != "T" or not login.get("username"):
            raise SessionExpired("25Live session expired. Run: cu25 login")
        return {"netid": login["username"], "name": login["contact_name"],
                "contact_id": int(login["user_id"])}

    def search_spaces(self, start: datetime, end: datetime, name: str | None = None,
                      min_capacity: int | None = None, page_size: int = 25) -> list[dict]:
        q = (f"scope=extended&can_schedule=T&perm_start_dt={P.fmt_dt(start)}"
             f"&perm_end_dt={P.fmt_dt(end)}&include=layouts&order=asc&sort=name"
             f"&page=1&page_size={page_size}&paginate")
        if min_capacity:
            q += f"&min_default_capacity={min_capacity}"
        if name:
            q += f"&name={httpx.QueryParams({'n': name})['n']}"
        return P.parse_spaces(self._call("GET", "spaces.json", q))

    def availability(self, space_ids: list[int], start: datetime, end: datetime) -> dict[int, dict]:
        if not space_ids:
            return {}
        resp = self._call("POST", "space_avail.json", body=P.availability_body(space_ids, start, end))
        return P.parse_availability(resp)

    def find_rooms(self, start: datetime, end: datetime, name: str | None = None,
                   people: int | None = None) -> list[dict]:
        rooms = self.search_spaces(start, end, name=name, min_capacity=people)
        avail = self.availability([r["space_id"] for r in rooms], start, end)
        for r in rooms:
            r.update(avail.get(r["space_id"], {"free": False}))
        return sorted(rooms, key=lambda r: (not r["free"], r["capacity"] or 0))

    def space_info(self, space_id: int) -> dict:
        """Scheduler contact and default layout for a room."""
        resp = self._call("POST", "spaces.json", "request_method=get", body={"mapxml": {
            "space_id": str(space_id), "scope": "extended",
            "include": "layouts+contacts+direct_schedule"}})
        return {"scheduler": P.parse_scheduler(resp), "layout_id": P.parse_default_layout(resp)}

    def event_template(self, event_id: int) -> dict:
        detail = self._call("GET", f"micro/event/{event_id}/detail.json", "expand=T&include=all")
        return P.template_from_detail(detail)

    def event_status(self, event_id: int) -> dict:
        detail = self._call("GET", f"micro/event/{event_id}/detail.json", "expand=T&include=all")
        item = detail["content"]["data"]["items"][0]
        states = {s["state"]: s["stateName"] for s in detail["content"]["expandedInfo"].get("states", [])}
        return {"event_id": item["id"], "reference": item.get("eventLocator"), "name": item["name"],
                "state": states.get(item["context"]["state"], item["context"]["state"]),
                "start": item["dates"]["startDate"], "end": item["dates"]["endDate"]}

    # ---- write ----------------------------------------------------------
    def request_room(self, template_event_id: int, start: datetime, end: datetime, *,
                     space_id: int | None = None, layout_id: int | None = None,
                     name: str | None = None, people: int | None = None,
                     description: str | None = None, dry_run: bool = False) -> dict:
        """Clone an existing event's form answers onto a new date/time (and optionally room)."""
        check_lead_time(start)
        tpl = self.event_template(template_event_id)
        if name: tpl["event_name"] = name
        if people: tpl["expected_count"] = people
        if description: tpl["description"] = f"<p>{description}</p>"
        if space_id and space_id != tpl["space_id"]:
            info = self.space_info(space_id)
            tpl["space_id"] = space_id
            tpl["layout_id"] = layout_id or info["layout_id"] or 23
            tpl["scheduler_id"], tpl["scheduler_name"] = info["scheduler"] or (None, "")

        avail = self.availability([tpl["space_id"]], start, end).get(tpl["space_id"], {})
        if not avail.get("free"):
            until = avail.get("conflict_until")
            raise CU25Error(f"Room {tpl['space_id']} is taken then"
                            + (f" (booked until {until})" if until else "") + ".")

        if dry_run:
            body = P.submit_body(tpl, event_id=0, profile_id=0, reservation_id=0, start=start, end=end)
            return {"dry_run": True, "body": body}

        event_id = self._seq("events")
        profile_id = self._seq("date_profile")
        self._call("PUT", "event.json", "prime", body=P.presave_body(event_id, datetime.now()))
        gen = self._call("POST", "micro/sequence/generate.json", "element=reservation&quantity=1")
        rsrv_id = gen["content"]["data"]["items"][0]["idSet"][0]["rsrvId"]
        body = P.submit_body(tpl, event_id=event_id, profile_id=profile_id,
                             reservation_id=rsrv_id, start=start, end=end)
        resp = self._call("PUT", "rose/event.json", f"event_id={event_id}&return_doc=T", body=body)
        return P.parse_submit(resp)
