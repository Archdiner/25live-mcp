"""cu25: book Cornell rooms from the terminal.

  cu25 login
  cu25 usual 561543                     # remember an event as your "usual" template
  cu25 find 2026-10-29 17:00 18:00 --people 20 --name stimson
  cu25 book 2026-10-29 17:00 18:00      # clone your usual onto a new slot
  cu25 book 2026-10-29 17:00 18:00 --room 976 --dry-run
  cu25 status 561543
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime

from .client import Client, CU25Error, SessionExpired, load_config, save_config


def _dt(day: str, hhmm: str) -> datetime:
    return datetime.fromisoformat(f"{day}T{hhmm}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="cu25", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("login")
    sub.add_parser("whoami")
    u = sub.add_parser("usual"); u.add_argument("event_id", type=int)
    f = sub.add_parser("find")
    for a in ("date", "start", "end"): f.add_argument(a)
    f.add_argument("--name"); f.add_argument("--people", type=int)
    b = sub.add_parser("book")
    for a in ("date", "start", "end"): b.add_argument(a)
    b.add_argument("--room", type=int, help="space_id (default: your usual room)")
    b.add_argument("--from-event", type=int, help="template event id (default: your usual)")
    b.add_argument("--title"); b.add_argument("--people", type=int)
    b.add_argument("--dry-run", action="store_true")
    s = sub.add_parser("status"); s.add_argument("event_id", type=int)
    args = ap.parse_args(argv)

    try:
        if args.cmd == "login":
            from .login import login
            print(f"Logged in as {login()}.")
            return 0
        if args.cmd == "usual":
            tpl = Client().event_template(args.event_id)
            save_config({**load_config(), "usual_event_id": args.event_id})
            print(f"Usual set: '{tpl['event_name']}' in space {tpl['space_id']}, "
                  f"{tpl['expected_count']} people.")
            return 0
        c = Client()
        if args.cmd == "whoami":
            out = c.whoami()
        elif args.cmd == "find":
            out = c.find_rooms(_dt(args.date, args.start), _dt(args.date, args.end),
                               name=args.name, people=args.people)
        elif args.cmd == "book":
            template = args.from_event or load_config().get("usual_event_id")
            if not template:
                raise CU25Error("No template. Run: cu25 usual <event_id>, or pass --from-event.")
            out = c.request_room(template, _dt(args.date, args.start), _dt(args.date, args.end),
                                 space_id=args.room, name=args.title, people=args.people,
                                 dry_run=args.dry_run)
        else:
            out = c.event_status(args.event_id)
        print(json.dumps(out, indent=2))
        return 0
    except (SessionExpired, CU25Error) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
