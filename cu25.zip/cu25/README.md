# cu25

Book Cornell rooms in 25Live (Scheduling@Cornell) by telling an agent "book our usual spot Thursday 5pm for an hour."

It works by cloning one of your existing requests (org, event type, all the activity questions) onto a new date and time, then submitting it the same way the 25Live website does. Requests still go to a human scheduler and show as **Tentative** until approved.

## Setup (once)

```bash
pip install -e .            # from this folder
playwright install chromium
cu25 login                  # a browser opens; sign in with NetID + Duo
cu25 usual 561543           # an event of yours to clone (the number in its 25Live URL)
```

The session cookie is saved to `~/.cu25/session.json` (only you can read it). Your password is never stored. When the session expires, commands tell you to run `cu25 login` again.

## Use it from the terminal

```bash
cu25 find 2026-10-29 17:00 18:00 --people 20 --name stimson   # free rooms first
cu25 book 2026-10-29 17:00 18:00 --dry-run                     # preview, sends nothing
cu25 book 2026-10-29 17:00 18:00                               # submit, usual room
cu25 book 2026-10-29 17:00 18:00 --room 976 --title "GenAI - Workshop"
cu25 status 561543
```

Requests must be at least 2 days out (the day after tomorrow is fine). Booking checks that the room is free first and refuses if it isn't.

## Use it from Claude

Add this to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json`) or Claude Code (`claude mcp add cu25 -- cu25-mcp`):

```json
{ "mcpServers": { "cu25": { "command": "cu25-mcp" } } }
```

Tools: `find_rooms`, `book_room`, `set_usual`, `request_status`.

## How it talks to 25Live

Base: `https://25live.collegenet.com/25live/data/cornell/run/`. Auth is the session cookie only (no CSRF token). The submit sequence, captured from the real web app:

| Step | Call |
| --- | --- |
| Read template | `GET micro/event/{id}/detail.json?expand=T&include=all` |
| Check room | `POST space_avail.json` |
| New event id | `GET sequence/id.json?itemName=events` |
| New date profile id | `GET sequence/id.json?itemName=date_profile` |
| Presave | `PUT event.json?prime` (state -1) |
| New reservation id | `POST micro/sequence/generate.json?element=reservation&quantity=1` |
| Submit | `PUT rose/event.json?event_id={id}&return_doc=T` (state 1 = Tentative) |

Room search is `GET spaces.json?scope=extended&can_schedule=T&perm_start_dt=...&name=...`. A room's scheduler and layouts come from `POST spaces.json?request_method=get`.

## Tests

`pytest` runs 12 tests against sanitized responses from a real session. The key one rebuilds a real submission from its template and checks it matches what the browser sent, field for field.

## Not yet verified live

- `find_rooms` checks availability without an event id. The web app always sent one, so if 25Live rejects that, check availability after the presave step.
- How long a session lasts before Duo is needed again.
- Booking a room other than your usual one (the scheduler and layout come from the room's own record, but that path hasn't been tried for real).
